package com.example.CuentasClarasSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import ttps.java.CuentasClarasSpring.model.Usuario;

@SpringBootTest
public class UsuarioTests {

	@Test
	void givenFirstName_whenCallingFindByFirstName_ThenReturnOnePerson() {
	//	Usuario usuario = usuarioRepository.findByFirstName("Mariana");
	//	assertNotNull(usuario);
	//	assertEquals("Mariana", usuario.getNombre());
	}
	
	//PAG10-TEORIA8

}
