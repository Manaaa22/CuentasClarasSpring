package ttps.java.CuentasClarasSpring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CuentasClarasSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(CuentasClarasSpringApplication.class, args);
	}

}
